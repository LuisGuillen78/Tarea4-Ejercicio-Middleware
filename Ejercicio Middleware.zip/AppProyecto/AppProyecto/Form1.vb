﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CargaDatos()

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim ObjWsProyecto As New WsProyecto.Service
        Dim Respuesta As String
        Respuesta = ObjWsProyecto.FnAgregarCarro(Me.TextBox1.Text, Me.TextBox2.Text, Me.TextBox3.Text, Me.TextBox4.Text)
        MessageBox.Show(Respuesta)
        CargaDatos()

        Me.TextBox1.Clear()
        Me.TextBox2.Clear()
        Me.TextBox3.Clear()
        Me.TextBox4.Clear()
    End Sub


    Private Sub CargaDatos()

        Dim ObjWsProyecto As New WsProyecto.Service
        Dim DsX As New DataSet

        DsX = ObjWsProyecto.FnMostrarRegistros
        Me.DGCarros.DataSource = DsX.Tables("Carros")



    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click


        Dim ObjWsProyecto As New WsProyecto.Service
        Dim Respuesta As String
        Respuesta = ObjWsProyecto.FnEliminarCarro(Me.TextBox1.Text)
        MessageBox.Show(Respuesta)
        CargaDatos()

        Me.TextBox1.Clear()

    End Sub
End Class
